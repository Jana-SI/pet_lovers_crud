function mostraImgTipo(tipo) {

    if (tipo == "ave") {
        document.getElementById('ave').style.display='inline-block';
        document.getElementById('cachorro').style.display = 'none';
        document.getElementById('chinchila').style.display = 'none';
        document.getElementById('coelho').style.display = 'none';
        document.getElementById('gato').style.display = 'none';
        document.getElementById('exotico').style.display = 'none';
        document.getElementById('hamster').style.display = 'none';
        document.getElementById('peixe').style.display = 'none';
        document.getElementById('porquinho_da_india').style.display = 'none';
    } 

    if (tipo == "cachorro") {
        document.getElementById('ave').style.display='none';
        document.getElementById('cachorro').style.display = 'inline-block';
        document.getElementById('chinchila').style.display = 'none';
        document.getElementById('coelho').style.display = 'none';
        document.getElementById('gato').style.display = 'none';
        document.getElementById('exotico').style.display = 'none';
        document.getElementById('hamster').style.display = 'none';
        document.getElementById('peixe').style.display = 'none';
        document.getElementById('porquinho_da_india').style.display = 'none';
    }

    if (tipo == "chinchila") {
        document.getElementById('ave').style.display='none';
        document.getElementById('cachorro').style.display = 'none';
        document.getElementById('chinchila').style.display = 'inline-block';
        document.getElementById('coelho').style.display = 'none';
        document.getElementById('gato').style.display = 'none';
        document.getElementById('exotico').style.display = 'none';
        document.getElementById('hamster').style.display = 'none';
        document.getElementById('peixe').style.display = 'none';
        document.getElementById('porquinho_da_india').style.display = 'none';
    }

    if (tipo == "coelho") {
        document.getElementById('ave').style.display='none';
        document.getElementById('cachorro').style.display = 'none';
        document.getElementById('chinchila').style.display = 'none';
        document.getElementById('coelho').style.display = 'inline-block';
        document.getElementById('gato').style.display = 'none';
        document.getElementById('exotico').style.display = 'none';
        document.getElementById('hamster').style.display = 'none';
        document.getElementById('peixe').style.display = 'none';
        document.getElementById('porquinho_da_india').style.display = 'none';
    }

    if (tipo == "gato") {
        document.getElementById('ave').style.display='none';
        document.getElementById('cachorro').style.display = 'none';
        document.getElementById('chinchila').style.display = 'none';
        document.getElementById('coelho').style.display = 'none';
        document.getElementById('gato').style.display = 'inline-block';
        document.getElementById('exotico').style.display = 'none';
        document.getElementById('hamster').style.display = 'none';
        document.getElementById('peixe').style.display = 'none';
        document.getElementById('porquinho_da_india').style.display = 'none';
    }

    if (tipo == "exotico") {
        document.getElementById('ave').style.display='none';
        document.getElementById('cachorro').style.display = 'none';
        document.getElementById('chinchila').style.display = 'none';
        document.getElementById('coelho').style.display = 'none';
        document.getElementById('gato').style.display = 'none';
        document.getElementById('exotico').style.display = 'inline-block';
        document.getElementById('hamster').style.display = 'none';
        document.getElementById('peixe').style.display = 'none';
        document.getElementById('porquinho_da_india').style.display = 'none';
    }

    if (tipo == "hamster") {
        document.getElementById('ave').style.display='none';
        document.getElementById('cachorro').style.display = 'none';
        document.getElementById('chinchila').style.display = 'none';
        document.getElementById('coelho').style.display = 'none';
        document.getElementById('gato').style.display = 'none';
        document.getElementById('exotico').style.display = 'none';
        document.getElementById('hamster').style.display = 'inline-block';
        document.getElementById('peixe').style.display = 'none';
        document.getElementById('porquinho_da_india').style.display = 'none';
    }

    if (tipo == "peixe") {
        document.getElementById('ave').style.display='none';
        document.getElementById('cachorro').style.display = 'none';
        document.getElementById('chinchila').style.display = 'none';
        document.getElementById('coelho').style.display = 'none';
        document.getElementById('gato').style.display = 'none';
        document.getElementById('exotico').style.display = 'none';
        document.getElementById('hamster').style.display = 'none';
        document.getElementById('peixe').style.display = 'inline-block';
        document.getElementById('porquinho_da_india').style.display = 'none';
    }

    if (tipo == "porquinho_da_india") {
        document.getElementById('ave').style.display='none';
        document.getElementById('cachorro').style.display = 'none';
        document.getElementById('chinchila').style.display = 'none';
        document.getElementById('coelho').style.display = 'none';
        document.getElementById('gato').style.display = 'none';
        document.getElementById('exotico').style.display = 'none';
        document.getElementById('hamster').style.display = 'none';
        document.getElementById('peixe').style.display = 'none';
        document.getElementById('porquinho_da_india').style.display = 'inline-block';
    }

    if(tipo == "" || tipo == "nao-declarado"){
        document.getElementById('ave').style.display='none';
        document.getElementById('cachorro').style.display = 'none';
        document.getElementById('chinchila').style.display = 'none';
        document.getElementById('coelho').style.display = 'none';
        document.getElementById('gato').style.display = 'none';
        document.getElementById('exotico').style.display = 'none';
        document.getElementById('hamster').style.display = 'none';
        document.getElementById('peixe').style.display = 'none';
        document.getElementById('porquinho_da_india').style.display = 'none';
    }
}